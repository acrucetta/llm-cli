from .anthropic import AnthropicProvider

PROVIDERS = {
    'anthropic': AnthropicProvider,
}